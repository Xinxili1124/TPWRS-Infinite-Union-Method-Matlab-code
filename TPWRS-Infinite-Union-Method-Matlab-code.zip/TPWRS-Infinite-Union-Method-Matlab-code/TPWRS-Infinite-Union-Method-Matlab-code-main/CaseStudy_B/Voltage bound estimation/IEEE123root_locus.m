clear
%% PV曲线——Voltage bound estimation
%%====== 初始化导纳矩阵 ======
Y=zeros(123,123);
Y(1,31)=1;Y(2,59)=2;Y(3,98)=1;Y(4,87)=2;Y(5,71)=1;Y(6,123)=2;Y(7,78)=5;Y(8,80)=5;Y(9,56)=5;Y(10,49)=2;Y(11,35)=1;Y(12,41)=2;Y(13,43)=2;Y(14,44)=2;Y(15,47)=10;Y(16,53)=2;Y(17,65)=1;
Y(18,68)=5;Y(19,70)=4;Y(20,72)=5;Y(21,91)=2;Y(22,84)=1;Y(23,96)=5;Y(24,100)=2;Y(25,103)=1;Y(26,108)=1;Y(27,112)=5;Y(28,115)=1;Y(29,118)=4;Y(30,122)=0.2;Y(31,34)=5;Y(32,33)=5;
Y(33,34)=2;Y(34,38)=1;Y(35,36)=4;Y(36,37)=5;Y(37,38)=2;Y(38,39)=5;Y(39,40)=1;Y(39,41)=5;Y(41,42)=10;Y(42,43)=5;Y(42,58)=2;Y(42,54)=2;Y(44,45)=1;Y(44,46)=5;Y(46,47)=2;Y(47,48)=2;Y(47,54)=2;Y(48,49)=5;Y(49,50)=5;Y(49,51)=1;Y(51,52)=5;Y(51,53)=1;Y(54,55)=1;Y(54,74)=10;Y(55,56)=4;Y(56,57)=1;Y(58,69)=1;Y(59,60)=1;Y(59,64)=10;Y(60,61)=5;Y(61,62)=4;Y(62,63)=1;Y(63,93)=0.5;Y(64,65)=5;Y(64,66)=2;Y(66,67)=5;Y(66,68)=0.5;Y(68,69)=10;Y(69,70)=2;Y(70,71)=1;Y(72,73)=4;Y(73,77)=2;Y(73,91)=2;Y(74,75)=1;Y(75,76)=5;Y(76,77)=1;Y(77,78)=2;Y(77,79)=1;Y(79,81)=5;Y(80,81)=4;Y(81,82)=4;Y(82,83)=2;Y(82,84)=1;Y(84,85)=4;Y(85,86)=5;Y(85,119)=2;Y(87,88)=1;Y(88,89)=2;
Y(89,90)=5;Y(90,91)=1;Y(91,92)=1;Y(92,109)=1;Y(93,94)=1;Y(94,95)=4;Y(94,99)=1;Y(95,96)=2;Y(96,97)=1;Y(97,98)=5;Y(99,100)=4;Y(99,101)=5;Y(101,102)=4;Y(101,104)=5;Y(102,103)=5;Y(104,105)=2;Y(105,106)=2;Y(105,109)=1;Y(106,107)=5;Y(107,108)=2;Y(109,110)=2;Y(109,113)=1;Y(110,111)=4;Y(111,112)=5;Y(113,114)=4;Y(113,116)=1;Y(114,115)=4;Y(116,117)=4;Y(116,119)=1;Y(117,118)=1;Y(118,120)=2;Y(120,121)=4;Y(121,122)=1;Y(121,123)=1;
Y=diag((Y+Y')*ones(123,1))-Y-Y';
YSS=Y(1:10,1:10); YSL=Y(1:10, 11:123); YLS=YSL'; YLL=Y(11:123,11:123);
K=diag([0.5 0.5 0.5 0.5 0.5 1 1 1 1 1]);
c=ones(1,10)*K^(-1)*YSS^(-1)*K^(-1)*ones(10,1);
alpha=(ones(1,10)*K^(-1)*YSS^(-1)*YSL)';
Y1=YLL-YLS*YSS^(-1)*YSL+alpha*alpha'*c^(-1);   
uref_fixed=5000;
%% ====== 现存静态电压稳定判据的负载PV曲线 ======
% 第一个判据 (f1) 的迭代
lambda_values1 = 1:0.001:10;  
f_list1 = []; lam_list1 = [];
for lambda1 = lambda_values1
    pL = [30*ones(31,1); 60*ones(31,1); 20*ones(31,1)]*1000*lambda1;
    pM = [20*ones(7,1); 40*ones(6,1); 60*ones(7,1)]*1000;
    T = Y1^(-1) * diag([-pM; pL]) / uref_fixed / uref_fixed;
    T_inf = norm(T,inf);  % T的∞范数

    if 4*T_inf > 1
        fprintf('第一个判据：λ=%.3f 时 T_inf=%.4f 超过 0.25，曲线停止。\n', lambda1, T_inf);
        break;
    end
    f_val1 = (1 + sqrt(1 - 4*T_inf)) / 2;
    lam_list1(end+1) = lambda1;
    f_list1(end+1) = f_val1;
end

% 第二个判据 (f2) 的迭代
lambda_values2 = 1:0.001:10;
f_list2 = []; lam_list2 = [];
for lambda2 = lambda_values2
    pL = [30*ones(31,1); 60*ones(31,1); 20*ones(31,1)]*1000*lambda2;
    pM = [20*ones(7,1); 40*ones(6,1); 60*ones(7,1)]*1000;
    T = Y1^(-1) * diag([-pM; pL]) / uref_fixed / uref_fixed;
    T_inf = norm(T,inf);
    T1n = norm(T,1);  
    root_val_2 = 1 - 2*sqrt(T_inf*norm(T*ones(113,1),inf)) - T_inf - norm(T*ones(113,1),inf);  

    if root_val_2 <= 0
        fprintf('第二个判据：λ=%.3f 时根号内部值为负，停止。\n', lambda2);
        break;
    end
    if root_val_2 >= 0
        f_val2 = (1 + sqrt(root_val_2)) / 2;
    else
        f_val2 = NaN;
    end
    lam_list2(end+1) = lambda2;
    f_list2(end+1) = f_val2;
end

% 第三个判据 (f3) 的迭代
lambda_values3 = 1:0.001:10;
f_list3 = []; lam_list3 = [];
for lambda3 = lambda_values3
    pL = [30*ones(31,1); 60*ones(31,1); 20*ones(31,1)]*1000*lambda3;
    pM = [20*ones(7,1); 40*ones(6,1); 60*ones(7,1)]*1000;
    T = Y1^(-1) * diag([-pM; pL]) / uref_fixed / uref_fixed;
    T_inf = norm(T,inf);
    root_val_3 = 1 - T_inf - 3 * (0.5 * norm(T*ones(113,1),inf))^(2/3);  

    if root_val_3 <= 0
        fprintf('第三个判据：λ=%.3f 时根号内部值为负，停止。\n', lambda3);
        break;
    end
    if root_val_3 >= 0
        f_val3 = (1 + sqrt(root_val_3)) / 2;
    else
        f_val3 = NaN;
    end
    lam_list3(end+1) = lambda3;
    f_list3(end+1) = f_val3;
end

%% ====== Actual Load Minimum Voltage 曲线计算 ======
lambda_values = 1:0.005:10;
pu1_list = []; lam_store = [];

for lambda = lambda_values
    pL = [30*ones(31,1); 60*ones(31,1); 20*ones(31,1)]*1000*lambda;
    pM = [20*ones(7,1); 40*ones(6,1); 60*ones(7,1)]*1000;
    T = Y1^(-1) * diag([-pM; pL]) / uref_fixed / uref_fixed;

    % 计算 u_L
    x = ones(113,1);
    for k = 1:10
        x = x - (eye(113) - T*diag(x)^(-2))^(-1) * ...
            (x + T*diag(x)^(-1)*ones(113,1) - ones(113,1)); 
    end
    min_x = min(x);

    % 归一化
    pu1 = min_x;
    lam_store(end+1) = lambda;
    pu1_list(end+1) = pu1;
end

% 截断函数
[lam1, pu1_list] = detect_jump(lam_store, pu1_list);
%% ====== 截断函数 ======
function [lam_out, pu_out] = detect_jump(lam, pu)
    dpu = diff(pu);
    idx_jump = find(dpu > 0, 1);
    if ~isempty(idx_jump)
        lam_out = lam(1:idx_jump);
        pu_out = pu(1:idx_jump);
    else
        lam_out = lam;
        pu_out = pu;
    end
end
%% ====== 本文所提判据对应的PV曲线 ======
% 扫描a,b
a_list = linspace(0.01,0.99,100);   % a在(0,1)，避免0分母
b_list = linspace(0.01,0.99,100);   % b在(0,1)，避免0分母

lambda5_step = 0.05;                % lambda增量
lambda5_max_global = 5;             % 可以先设一个大上界，再由条件判断截断

PV_results = [];  % 存储最终的(λ, P/V点)

for ai = 1:length(a_list)
    a = a_list(ai);
    for bi = 1:length(b_list)
        b = b_list(bi);

        % 从lambda=1开始逐渐增加
        lambda5 = 1;
        while true
            % --- 计算T ---
            pL = [30*ones(31,1); 60*ones(31,1); 20*ones(31,1)]*1000*lambda5;
             pM = [20*ones(7,1); 40*ones(6,1); 60*ones(7,1)]*1000;
            T = Y1^(-1) * diag([-pM; pL]) / uref_fixed / uref_fixed;   % 注意pM需定义
            T1 = T.*(T>0);
            T2 = -T.*(T<0);
            s = T1*ones(113,1);   % T11n
            r = T2*ones(113,1);   % T21n

           expr1 = (s/(a*(1-a)) - r/(a*(1+b)));   % 113×1  通过不动点定理构造映射得到上下界
expr2 = (r/(b*(1-a)) - s/(b*(1+b)));   % 113×1
cond1 = (1 - expr1);   % 113×1  
cond2 = (1 - expr2);   % 113×1

if all(cond1 >= 0) && all(cond2 >= 0)
    % 两个条件都满足
    val1 = 1-norm( expr1, inf);   % ||1 - expr1||∞
    val2 = 1-norm(expr2, inf);   % ||1 - expr2||∞
    root_val = min(val1, val2); %% 最小电压边界轨迹，故取两者小值

    y = (1 + sqrt(root_val)) / 2;%% 潮流方程解的求根公式
    PV_results = [PV_results; lambda5, y];
else
    % 有不满足的情况 -> 到达lambda_max
    break;
end
            % 增加lambda
            lambda5 = lambda5 + lambda5_step;
            if lambda5 > lambda5_max_global
                break;
            end
        end
    end
end

% --------- 后处理：取每个lambda截面最大值 ----------
unique_lambda5 = unique(PV_results(:,1));
PV_curve = zeros(length(unique_lambda5),2);
for i = 1:length(unique_lambda5)
    lam = unique_lambda5(i);
    idx = PV_results(:,1) == lam;
    PV_curve(i,1) = lam;
    PV_curve(i,2) = max(PV_results(idx,2));
end
%% ====== 绘图 ======
figure;
hold on;
plot(lam1, pu1_list, 'k-', 'LineWidth', 2, 'DisplayName', 'Actual voltage');
plot(PV_curve(:,1), PV_curve(:,2), 'b-.', 'LineWidth', 2, 'DisplayName', 'Proposed bound'); % 第五判据
plot(lam_list3, f_list3, 'm:', 'LineWidth', 2, 'DisplayName', 'Bound by [29]');
plot(lam_list2, f_list2, 'g:', 'LineWidth', 2, 'DisplayName', 'Bound by [26]');
plot(lam_list1, f_list1, 'r--', 'LineWidth', 2, 'DisplayName', 'Bound by [23]');
grid on;
ax = gca;
legend('show','FontSize',16,'FontName','Times New Roman');
ax.XGrid = 'off';
ax.YGrid = 'on';
ax.GridColor = [0.6 0.6 0.6];
ax.GridAlpha = 0.5;
xlabel('Loading factor', 'FontName', 'Times New Roman', 'FontSize', 18);
ylabel('Voltage (p.u.)', 'FontName', 'Times New Roman', 'FontSize', 18);
ax.FontName = 'Times New Roman';
ax.FontSize = 18;
box on;
set(gca,'FontName','Times New Roman','FontSize',18,'LineWidth',1.1);



