clear
%% Y and Y1 %%
Y=zeros(33,33);
Y(1,11)=5; Y(2,23)=5; Y(3,27)=5; Y(4,33)=1;
Y(5,25)=5; Y(6,11)=5; Y(6,24)=2; Y(7,11)=10;
Y(7,12)=2; Y(7,26)=5; Y(8,15)=0.5; Y(8,16)=1;
Y(9,19)=5; Y(9,20)=0.5; Y(10,30)=0.5; Y(10,31)=2;
Y(12,13)=10; Y(13,14)=2; Y(14,15)=1; Y(14,28)=5;
Y(16,17)=0.5; Y(17,18)=1; Y(18,19)=1; Y(20,21)=1;
Y(21,22)=2; Y(22,23)=0.5; Y(24,25)=5; Y(26,27)=0.5;
Y(28,29)=1; Y(29,30)=5; Y(31,32)=5; Y(32,33)=1;
Y=diag((Y+Y')*ones(33,1))-Y-Y';
 %% Y is obtained %%
YSS=Y(1:5,1:5); YSL=Y(1:5, 6:33); YLS=YSL';YLL=Y(6:33,6:33);
K=diag([0.5 0.5 0.5 1 1]);
c=ones(1,5)*K^(-1)*YSS^(-1)*K^(-1)*ones(5,1);alpha=(ones(1,5)*K^(-1)*YSS^(-1)*YSL)';
Y1=YLL-YLS*YSS^(-1)*YSL+alpha*alpha'*c^(-1); %% Y1 is obtained %%
uref=5000;
%% 求解不同判据对应的极限负载因子λ------求解本文判据对应的lambda
lambda = 2;              % 初始负载系数
lambda_step = 0.0001;     % 每次增加的步长
max_lambda = 100;          % 限制最大 lambda
last_valid_lambda = NaN; % 保存最后一个合法 lambda

while lambda <= max_lambda
    % 负载和发电功率
    pL=[6*ones(8,1);6.5*ones(7,1);7*ones(8,1)]*10000*lambda;
    pM=[3*ones(2,1);3.2*ones(1,1);3.4*ones(2,1)]*20000;

    % 计算 T, T1, T2
    T=Y1^(-1)*diag([-pM;pL])/uref/uref;  
    T1=T.*(T>0); 
    T2=-T.*(T<0);  
    s=T1*ones(28,1); r=T2*ones(28,1);
    % 判断是否所有点都在区域内
    all_inside = true;
    for i=1:length(s)
        x = s(i); y = r(i);
        if x <= 0.6
            if x <= 1/4
                inside = (y >= 0) && (y <= (2/3)*x+0.5);
            elseif x <= (3-sqrt(5))/2
                inside = (y >= 2*sqrt(x)-1) && (y <= (2/3)*x+0.5);
            else
                inside = (y >= x^2/(1-x)) && (y <= (2/3)*x+0.5);
            end
        else
            inside = false; % 超出最大x范围
        end

        if ~inside
            all_inside = false;
            break; % 有一个点出界就停
        end
    end

    if all_inside
        last_valid_lambda = lambda; % 记录下最后合法的 λ
        lambda = lambda + lambda_step; % 继续增大
    else
        break; % 已经越界，直接停
    end
end

if ~isnan(last_valid_lambda)
    disp(['最大合法 lambda = ', num2str(last_valid_lambda)]);
else
    disp('没有找到合法的 lambda');
end
%%  %% 计算牛拉算法对应的极限负载因子——真实λ值
lambda_values = 1:0.001:100;   % lambda 扫描范围
tol   = 1e-6;                 % 收敛容差
maxit = 50;                   % 单个 lambda 的最大迭代次数
max_lambda = NaN;             % 用来保存最后收敛的 λ

for lambda = lambda_values
    % 负荷按 lambda 逐步放大
    pL=[6*ones(8,1);6.5*ones(7,1);7*ones(8,1)]*10000*lambda;
    pM=[3*ones(2,1);3.2*ones(1,1);3.4*ones(2,1)]*20000;
    T=Y1^(-1)*diag([-pM;pL])/uref/uref;  
    % 初值
    x = ones(28,1);
    converged = false;

    for k = 1:maxit
        F  = x + T*diag(x)^(-1)*ones(28,1) - ones(28,1);
        J  = eye(28) - T*diag(x)^(-2);
        dx = J \ F;
        x  = x - dx;

        % 判断是否收敛
        if any(isnan(x)) || any(isinf(x))     % 数值溢出
            break
        end
        if norm(dx,inf) < tol                 % 收敛
            converged = true;
            break
        end
    end

    if ~converged
        fprintf('牛顿迭代在 lambda = %.3f 时开始发散。\n', lambda);
        break
    else
        max_lambda = lambda;   % 记录最后一次收敛的 λ
    end
end

fprintf('能够收敛的最大 lambda 为 %.3f\n', max_lambda);
%% ---------------------计算现存判据对应的极限负载因子λ---------------------- %%
lambda_low = 1;        % λ 的下界
lambda_high = 100;     % λ 的上界
tol = 1e-4;            % 精度要求（相当于步长法 0.0001）
max_iter = 100;        % 最多迭代次数
last_valid_lambda = NaN;
last_b1 = NaN;

for iter = 1:max_iter
    lambda_mid = (lambda_low + lambda_high) / 2;
    % 负载和发电功率
   pL=[6*ones(8,1);6.5*ones(7,1);7*ones(8,1)]*10000*lambda_mid;
    pM=[3*ones(2,1);3.2*ones(1,1);3.4*ones(2,1)]*20000;
    % 计算 T
    T=Y1^(-1)*diag([-pM;pL])/uref/uref;  
%% 计算第一个判据的数值
b1=4*norm(T,inf);
%计算第二个判据的数值%
b2=norm(T,inf)+3*(norm(T*ones(28,1),inf)/2 )^(2/3);
%计算第三个判据的数值%
b3=2*sqrt(norm(T,inf)*norm(T*ones(28,1),inf))+norm(T*ones(28,1),inf)+norm(T,inf);
    % 判断 b1 是否超过 1
    if b1 <= 1
        last_valid_lambda = lambda_mid;
        last_b1 = b1;
        last_b2 = b2;
        last_b3 = b3;
        lambda_low = lambda_mid;   % b1 太小，可以增大 λ
    else
        lambda_high = lambda_mid;  % b1 太大，缩小 λ
    end

    % 停止条件：区间足够小
    if (lambda_high - lambda_low) < tol
        break;
    end
end

if ~isnan(last_valid_lambda)
    disp(['最大合法 lambda = ', num2str(last_valid_lambda)]);
    disp(['对应的 b1 = ', num2str(last_b1)]);
    disp(['对应的 b2 = ', num2str(last_b2)]);
    disp(['对应的 b3 = ', num2str(last_b3)]);
else
    disp('没有找到合法的 lambda');
end



