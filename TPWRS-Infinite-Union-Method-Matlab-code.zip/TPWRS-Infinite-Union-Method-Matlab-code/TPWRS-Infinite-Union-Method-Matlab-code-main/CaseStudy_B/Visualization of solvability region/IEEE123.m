clear; clc; close all;
%% %% IEEE-123系统
Y=zeros(123,123);
Y(1,31)=1;Y(2,59)=2;Y(3,98)=1;Y(4,87)=2;Y(5,71)=1;Y(6,123)=2;Y(7,78)=5;Y(8,80)=5;Y(9,56)=5;Y(10,49)=2;Y(11,35)=1;Y(12,41)=2;Y(13,43)=2;Y(14,44)=2;Y(15,47)=10;Y(16,53)=2;Y(17,65)=1;
Y(18,68)=5;Y(19,70)=4;Y(20,72)=5;Y(21,91)=2;Y(22,84)=1;Y(23,96)=5;Y(24,100)=2;Y(25,103)=1;Y(26,108)=1;Y(27,112)=5;Y(28,115)=1;Y(29,118)=4;Y(30,122)=0.2;Y(31,34)=5;Y(32,33)=5;
Y(33,34)=2;Y(34,38)=1;Y(35,36)=4;Y(36,37)=5;Y(37,38)=2;Y(38,39)=5;Y(39,40)=1;Y(39,41)=5;Y(41,42)=10;Y(42,43)=5;Y(42,58)=2;Y(42,54)=2;Y(44,45)=1;Y(44,46)=5;Y(46,47)=2;Y(47,48)=2;Y(47,54)=2;Y(48,49)=5;Y(49,50)=5;Y(49,51)=1;Y(51,52)=5;Y(51,53)=1;Y(54,55)=1;Y(54,74)=10;Y(55,56)=4;Y(56,57)=1;Y(58,69)=1;Y(59,60)=1;Y(59,64)=10;Y(60,61)=5;Y(61,62)=4;Y(62,63)=1;Y(63,93)=0.5;Y(64,65)=5;Y(64,66)=2;Y(66,67)=5;Y(66,68)=0.5;Y(68,69)=10;Y(69,70)=2;Y(70,71)=1;Y(72,73)=4;Y(73,77)=2;Y(73,91)=2;Y(74,75)=1;Y(75,76)=5;Y(76,77)=1;Y(77,78)=2;Y(77,79)=1;Y(79,81)=5;Y(80,81)=4;Y(81,82)=4;Y(82,83)=2;Y(82,84)=1;Y(84,85)=4;Y(85,86)=5;Y(85,119)=2;Y(87,88)=1;Y(88,89)=2;
Y(89,90)=5;Y(90,91)=1;Y(91,92)=1;Y(92,109)=1;Y(93,94)=1;Y(94,95)=4;Y(94,99)=1;Y(95,96)=2;Y(96,97)=1;Y(97,98)=5;Y(99,100)=4;Y(99,101)=5;Y(101,102)=4;Y(101,104)=5;Y(102,103)=5;Y(104,105)=2;Y(105,106)=2;Y(105,109)=1;Y(106,107)=5;Y(107,108)=2;Y(109,110)=2;Y(109,113)=1;Y(110,111)=4;Y(111,112)=5;Y(113,114)=4;Y(113,116)=1;Y(114,115)=4;Y(116,117)=4;Y(116,119)=1;Y(117,118)=1;Y(118,120)=2;Y(120,121)=4;Y(121,122)=1;Y(121,123)=1;
Y=diag((Y+Y')*ones(123,1))-Y-Y'; %% Y is obtained %%
YSS=Y(1:10,1:10); YSL=Y(1:10, 11:123); YLS=YSL';YLL=Y(11:123,11:123);
K=diag([0.5 0.5 0.5 0.5 0.5 1 1 1 1 1]);
c=ones(1,10)*K^(-1)*YSS^(-1)*K^(-1)*ones(10,1);alpha=(ones(1,10)*K^(-1)*YSS^(-1)*YSL)';
Y1=YLL-YLS*YSS^(-1)*YSL+alpha*alpha'*c^(-1); %% Y1 is obtained %%
uref=5000;
pL=[30*ones(31,1);60*ones(31,1);20*ones(31,1)]*1000;
pM=[20*ones(7,1);40*ones(6,1);60*ones(7,1)]*1000;
%% %% ========== 扫描参数 ==========
Ndir  = 360;     % 扫描方向数 
steps = [1e2, 1e2, 1e2, 1e2];   % 每个判据的 λ 步长，自己可调整
%% ========== 四个判据边界 ==========
boundary_tmp = cell(4,1);
h=1;g=93;%% 选中的负载 
m=93;%%负载pL总数
v=113;%%MPPT+CPL总数

for crit = 1:4
    boundary_points = [];
    step = steps(crit);   % 针对当前判据的步长
    for k = 1:Ndir
        theta = 2*pi*(k-1)/Ndir;
        d29 = ones(m,1);
        d29(h)  = cos(theta);
        d29(g) = sin(theta);

        lambda = 0;
        inside = true;

        % 逐步增加功率直到判据不满足
        while inside
            lambda = lambda + step;
            pL_try = pL+ lambda*d29;
            T = Y1^(-1)*diag([-pM; pL_try])/uref/uref;

            switch crit
                case 1
                    bval = 4*norm(T,inf);
                    inside = (bval <= 1);
                case 2
                    bval = norm(T,inf) + 3*(norm(T*ones(v,1),inf)/2)^(2/3);
                    inside = (bval <= 1);
                case 3
                    bval = 2*sqrt(norm(T,inf)*norm(T*ones(v,1),inf)) ...
                         + norm(T*ones(v,1),inf) + norm(T,inf);
                    inside = (bval <= 1);
                case 4
                    T1 = T.*(T>0);
                    T2 = -T.*(T<0);
                    s = T1*ones(v,1);
                    r = T2*ones(v,1);
                    inside = true;
                    for i = 1:length(s)
                        x = s(i); y = r(i);
                        if x <= 2/3
                            if x <= 1/4
                                ok = (y >= 0) && (y <= 0.5*x+1);
                            elseif x <= (3-sqrt(5))/2
                                ok = (y >= 2*sqrt(x)-1) && (y <= 0.5*x+1);
                            else
                                ok = (y >= x^2/(1-x)) && (y <= 0.5*x+1);
                            end
                        else
                            ok = false;
                        end
                        if ~ok
                            inside = false;
                            break;
                        end
                    end
            end
        end

        % 回退一个步长，取边界点
        lambda = lambda - step;
        P1 = pL(h) + lambda*d29(h);
        P2 = pL(g) + lambda*d29(g);
        boundary_points = [boundary_points; [P1, P2]];
    end
    boundary_tmp{crit} = boundary_points;
end
%%  ========== 牛顿真实边界 ==========
boundary_nr = [];
for k = 1:Ndir
    theta = 2*pi*(k-1)/Ndir;
    d29 = ones(m,1);
    d29(h)  = cos(theta);
    d29(g) = sin(theta);

    % --- 二分法搜索 ---
    lambda = 0;
    step =1e6;   % 初始粗步长

    pL_try = pL + lambda*d29;
    T = Y1^(-1)*diag([-pM; pL_try])/uref/uref;
    inside = newton_check(T,v);
    if ~inside
        break;  % 已经越界，跳出
    end
    lambda = lambda + step;

    % refine
    lo = max(0, lambda-step);
    hi = lambda;
    for refine = 1:50
        mid = (lo+hi)/2;
        pL_try = pL + mid*d29;
        T = Y1^(-1)*diag([-pM; pL_try])/uref/uref;
        inside = newton_check(T,v);
        if inside
            lo = mid;
        else
            hi = mid;
        end
    end

    % 边界点
    P1 = pL(h) + lo*d29(h);
    P2 = pL(g) + lo*d29(g);
    boundary_nr = [boundary_nr; [P1, P2]];
end

% ========== 按需求顺序重排 ==========
boundary_all = cell(5,1);
boundary_all{1} = boundary_nr*1e-5;       % Actual (黑色)
boundary_all{2} = boundary_tmp{4}*1e-5;   % Proposed (蓝色)
boundary_all{3} = boundary_tmp{2}*1e-5;   % [29] 玫红
boundary_all{4} = boundary_tmp{3}*1e-5;   % [26] 绿色
boundary_all{5} = boundary_tmp{1}*1e-5;   % [23] 红色
figure; hold on; grid on; box on;

% 颜色顺序: 黑, 蓝, 玫红, 绿, 红
clr   = {'k','b','m','g','r'}; 
% 线型顺序: 实线, 虚线, 点线, 点划线, 点划线 (可调整)
lns   = {'-','--',':','-.','-.'};  
labels = {'Actual bound','Proposed bound','Bound by [29]','Bound by [26]','Bound by [23]'};
lw    = [1.5 1.5 1.5 1.5 1.5];   % 黑色实线稍粗, 其余正常

for crit = 1:5
    plot(boundary_all{crit}(:,1), boundary_all{crit}(:,2), ...
        'Color', clr{crit}, 'LineStyle', lns{crit}, ...
        'LineWidth', lw(crit), 'DisplayName', labels{crit});
end


xlabel('$P_{1}$','Interpreter','latex','FontName','Times New Roman','FontSize',20);
ylabel('$P_{2}$','Interpreter','latex','FontName','Times New Roman','FontSize',20);
lgd = legend('show','Orientation','vertical', ...
    'FontName','Times New Roman','FontSize',12);  % 图例用Times New Roman
lgd.ItemTokenSize = [15,18];   % 调整图例线段长度
set(gca,'FontName','Times New Roman','FontSize',20,'LineWidth',1.1);

% ========== 收敛判定函数 ==========
function converged = newton_check(T,n)
    tol = 1e-10;
    max_iter = 10;
    x = ones(n,1);  % 初始解
    converged = false;

    for it = 1:max_iter
        try
            x_new = x - (eye(n) - T*diag(x.^(-2))) \ ...
                        (x + T*(1./x) - ones(n,1));
        catch
            return; % 矩阵奇异 -> 不收敛
        end
        % --- 收敛误差判定 ---
        error = x_new + T*diag(1./x_new)*ones(n,1) - ones(n,1);
        if max(abs(error)) < tol
            converged = true;
            return;
        end
        x = x_new;
    end
end
