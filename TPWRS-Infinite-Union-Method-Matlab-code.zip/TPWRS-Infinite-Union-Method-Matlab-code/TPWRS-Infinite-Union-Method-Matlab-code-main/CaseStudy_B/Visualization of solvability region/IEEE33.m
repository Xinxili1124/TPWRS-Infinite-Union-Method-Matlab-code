clear; clc; close all;
%% IEEE-33系统
%Y and Y1 %%
Y=zeros(33,33);
Y(1,11)=5; Y(2,23)=5; Y(3,27)=5; Y(4,33)=1;
Y(5,25)=5; Y(6,11)=5; Y(6,24)=2; Y(7,11)=10;
Y(7,12)=2; Y(7,26)=5; Y(8,15)=0.5; Y(8,16)=1;
Y(9,19)=5; Y(9,20)=0.5; Y(10,30)=0.5; Y(10,31)=2;
Y(12,13)=10; Y(13,14)=2; Y(14,15)=1; Y(14,28)=5;
Y(16,17)=0.5; Y(17,18)=1; Y(18,19)=1; Y(20,21)=1;
Y(21,22)=2; Y(22,23)=0.5; Y(24,25)=5; Y(26,27)=0.5;
Y(28,29)=1; Y(29,30)=5; Y(31,32)=5; Y(32,33)=1;
Y=diag((Y+Y')*ones(33,1))-Y-Y';
 % Y is obtained %%
YSS=Y(1:5,1:5); YSL=Y(1:5, 6:33); YLS=YSL';YLL=Y(6:33,6:33);
K=diag([0.5 0.5 0.5 1 1]);
c=ones(1,5)*K^(-1)*YSS^(-1)*K^(-1)*ones(5,1);alpha=(ones(1,5)*K^(-1)*YSS^(-1)*YSL)';
Y1=YLL-YLS*YSS^(-1)*YSL+alpha*alpha'*c^(-1); %% Y1 is obtained %%
uref=5000;
    pL=[6*ones(8,1);6.5*ones(7,1);7*ones(8,1)]*10000;
    pM=[3*ones(2,1);3.2*ones(1,1);3.4*ones(2,1)]*20000;
%% %% ========== 扫描参数 ==========
Ndir  = 360;     % 扫描方向数 
steps = [1e3, 1e3, 1e3, 1e3];   % 每个判据的 λ 步长，自己可调整
%% ========== 四个判据边界 ==========
boundary_tmp = cell(4,1);
h=1;g=16;%% 选中的负载 
m=23;%%负载pL总数
v=28;%%MPPT+CPL总数

for crit = 1:4
    boundary_points = [];
    step = steps(crit);   % 针对当前判据的步长
    for k = 1:Ndir
        theta = 2*pi*(k-1)/Ndir;
        d29 = ones(m,1);
        d29(h)  = cos(theta);
        d29(g) = sin(theta);

        lambda = 0;
        inside = true;

        % 逐步增加功率直到判据不满足
        while inside
            lambda = lambda + step;
            pL_try = pL+ lambda*d29;
            T = Y1^(-1)*diag([-pM; pL_try])/uref/uref;

            switch crit
                case 1
                    bval = 4*norm(T,inf);
                    inside = (bval <= 1);
                case 2
                    bval = norm(T,inf) + 3*(norm(T*ones(v,1),inf)/2)^(2/3);
                    inside = (bval <= 1);
                case 3
                    bval = 2*sqrt(norm(T,inf)*norm(T*ones(v,1),inf)) ...
                         + norm(T*ones(v,1),inf) + norm(T,inf);
                    inside = (bval <= 1);
                case 4
                    T1 = T.*(T>0);
                    T2 = -T.*(T<0);
                    s = T1*ones(v,1);
                    r = T2*ones(v,1);
                    inside = true;
                    for i = 1:length(s)
                        x = s(i); y = r(i);
                        if x <= 2/3
                            if x <= 1/4
                                ok = (y >= 0) && (y <= 0.5*x+1);
                            elseif x <= (3-sqrt(5))/2
                                ok = (y >= 2*sqrt(x)-1) && (y <= 0.5*x+1);
                            else
                                ok = (y >= x^2/(1-x)) && (y <= 0.5*x+1);
                            end
                        else
                            ok = false;
                        end
                        if ~ok
                            inside = false;
                            break;
                        end
                    end
            end
        end

        % 回退一个步长，取边界点
        lambda = lambda - step;
        P1 = pL(h) + lambda*d29(h);
        P2 = pL(g) + lambda*d29(g);
        boundary_points = [boundary_points; [P1, P2]];
    end
    boundary_tmp{crit} = boundary_points;
end
%% ========== 牛顿真实边界 ==========
boundary_nr = [];
for k = 1:Ndir
    theta = 2*pi*(k-1)/Ndir;
    d29 = ones(m,1);
    d29(h)  = cos(theta);
    d29(g) = sin(theta);

    % --- 二分法搜索 ---
    lambda = 0;
    step =1.8e5;   % 初始粗步长

    pL_try = pL + lambda*d29;
    T = Y1^(-1)*diag([-pM; pL_try])/uref/uref;
    inside = newton_check(T,v);
    if ~inside
        break;  % 已经越界，跳出
    end
    lambda = lambda + step;

    % refine
    lo = max(0, lambda-step);
    hi = lambda;
    for refine = 1:50
        mid = (lo+hi)/2;
        pL_try = pL + mid*d29;
        T = Y1^(-1)*diag([-pM; pL_try])/uref/uref;
        inside = newton_check(T,v);
        if inside
            lo = mid;
        else
            hi = mid;
        end
    end

    % 边界点
    P1 = pL(h) + lo*d29(h);
    P2 = pL(g) + lo*d29(g);
    boundary_nr = [boundary_nr; [P1, P2]];
end

% ========== 按需求顺序重排 ==========
boundary_all = cell(5,1);
boundary_all{1} = boundary_nr*1e-5;       % Actual (黑色)
boundary_all{2} = boundary_tmp{4}*1e-5;   % Proposed (蓝色)
boundary_all{3} = boundary_tmp{2}*1e-5;   % [29] 玫红
boundary_all{4} = boundary_tmp{3}*1e-5;   % [26] 绿色
boundary_all{5} = boundary_tmp{1}*1e-5;   % [23] 红色
figure; hold on; grid on; box on;

% 颜色顺序: 黑, 蓝, 玫红, 绿, 红
clr   = {'k','b','m','g','r'}; 
% 线型顺序: 实线, 虚线, 点线, 点划线, 点划线 (可调整)
lns   = {'-','--',':','-.','-.'};  
labels = {'Actual bound','Proposed bound','Bound by [29]','Bound by [26]','Bound by [23]'};
lw    = [1.5 1.5 1.5 1.5 1.5];   % 黑色实线稍粗, 其余正常

for crit = 1:5
    plot(boundary_all{crit}(:,1), boundary_all{crit}(:,2), ...
        'Color', clr{crit}, 'LineStyle', lns{crit}, ...
        'LineWidth', lw(crit), 'DisplayName', labels{crit});
end


xlabel('$P_{1}$','Interpreter','latex','FontName','Times New Roman','FontSize',20);
ylabel('$P_{2}$','Interpreter','latex','FontName','Times New Roman','FontSize',20);
lgd = legend('show','Orientation','vertical', ...
    'FontName','Times New Roman','FontSize',12);  % 图例用Times New Roman
lgd.ItemTokenSize = [15,18];   % 调整图例线段长度
set(gca,'FontName','Times New Roman','FontSize',20,'LineWidth',1.1);

% ========== 收敛判定函数 ==========
function converged = newton_check(T,n)
    tol = 1e-10;
    max_iter = 10;
    x = ones(n,1);  % 初始解
    converged = false;

    for it = 1:max_iter
        try
            x_new = x - (eye(n) - T*diag(x.^(-2))) \ ...
                        (x + T*(1./x) - ones(n,1));
        catch
            return; % 矩阵奇异 -> 不收敛
        end
        % --- 收敛误差判定 ---
        error = x_new + T*diag(1./x_new)*ones(n,1) - ones(n,1);
        if max(abs(error)) < tol
            converged = true;
            return;
        end
        x = x_new;
    end
end
