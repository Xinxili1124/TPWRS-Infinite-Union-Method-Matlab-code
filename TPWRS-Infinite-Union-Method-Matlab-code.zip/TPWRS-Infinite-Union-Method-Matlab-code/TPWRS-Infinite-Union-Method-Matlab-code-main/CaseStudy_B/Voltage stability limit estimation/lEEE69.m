clear
%% 
Y=zeros(69,69);
Y(1,50)=1; Y(2,41)=1; Y(2,51)=0.2; Y(3,41)=0.25; Y(3,42)=0.5;
Y(4,43)=0.5; Y(5,44)=1; Y(5,52)=0.5; Y(6,45)=0.2;
Y(7,46)=1; Y(7,54)=0.2; Y(8,47)=0.5; Y(8,48)=1;
Y(9,49)=0.25; Y(10,64)=0.2; Y(11,55)=0.25; Y(11,56)=1;
Y(11,57)=0.2; Y(12,56)=0.5; Y(13,58)=0.2; Y(13,59)=0.5;
Y(14,60)=0.25; Y(14,61)=0.2; Y(15,61)=0.5; Y(15,62)=1;
Y(16,63)=0.2; Y(17,65)=0.25; Y(18,51)=0.5; Y(18,66)=0.2;
Y(19,67)=0.5; Y(19,68)=1; Y(20,69)=1; Y(21,22)=0.2;
Y(21,42)=1; Y(22,43)=0.25; Y(23,24)=0.25; Y(23,46)=0.5; Y(24,25)=0.2;
Y(25,47)=1; Y(26,27)=0.25; Y(26,48)=0.5; Y(27,28)=0.2;
Y(28,49)=0.2; Y(29,30)=0.5; Y(29,52)=0.2; Y(30,53)=0.25;
Y(31,53)=0.5; Y(31,54)=1; Y(31,64)=0.25; Y(32,57)=0.5;
Y(32,58)=1; Y(33,59)=1; Y(33,60)=1; Y(34,35)=0.5;
Y(34,62)=1; Y(35,36)=0.25; Y(36,63)=0.2; Y(37,66)=1;
Y(37,67)=0.25; Y(38,39)=0.25; Y(38,68)=0.2; Y(39,40)=1;
Y(40,69)=0.5; Y(44,45)=0.25; Y(50,51)=0.5; Y(51,52)=0.25;
Y(54,55)=0.5; Y(57,65)=1; 
Y=diag((Y+Y')*ones(69,1))-Y-Y';
 %% Y is obtained %%
YSS=Y(1:20,1:20); YSL=Y(1:20, 21:69); YLS=YSL';YLL=Y(21:69,21:69);
K=diag([0.5 0.5 0.5 0.5 0.5 0.5 0.5 0.5 0.5 0.5 1 1 1 1 1 1 1 1 1 1]);
c=ones(1,20)*K^(-1)*YSS^(-1)*K^(-1)*ones(20,1);alpha=(ones(1,20)*K^(-1)*YSS^(-1)*YSL)';
Y1=YLL-YLS*YSS^(-1)*YSL+alpha*alpha'*c^(-1); %% Y1 is obtained %%
uref=5000;
%% 基本负荷数据
  pL=[0.8*ones(10,1);1*ones(9,1);1.2*ones(10,1)]*10000;
 pM=[0.5*ones(7,1);1*ones(6,1);1.5*ones(7,1)]*10000;
%% 求解不同判据对应的极限负载因子λ------求解本文判据对应的lambda
lambda = 1;              % 初始负载系数
lambda_step = 0.0001;     % 每次增加的步长
max_lambda = 50;          % 限制最大 lambda
last_valid_lambda = NaN; % 保存最后一个合法 lambda

while lambda <= max_lambda
    % 负载和发电功率
 pL=[0.8*ones(10,1);1*ones(9,1);1.2*ones(10,1)]*10000*lambda;
 pM=[0.5*ones(7,1);1*ones(6,1);1.5*ones(7,1)]*10000;

    % 计算 T, T1, T2
    T=Y1^(-1)*diag([-pM;pL])/uref/uref;  
    T1=T.*(T>0); 
    T2=-T.*(T<0);  
    s=T1*ones(49,1); r=T2*ones(49,1);
    % 判断是否所有点都在区域内
    all_inside = true;
    for i=1:length(s)
        x = s(i); y = r(i);
        if x <= 2/3
            if x <= 1/4
                inside = (y >= 0) && (y <= 0.5*x+1);
            elseif x <= (3-sqrt(5))/2
                inside = (y >= 2*sqrt(x)-1) && (y <= 0.5*x+1);
            else
                inside = (y >= x^2/(1-x)) && (y <= 0.5*x+1);
            end
        else
            inside = false; % 超出最大x范围
        end

        if ~inside
            all_inside = false;
            break; % 有一个点出界就停
        end
    end

    if all_inside
        last_valid_lambda = lambda; % 记录下最后合法的 λ
        lambda = lambda + lambda_step; % 继续增大
    else
        break; % 已经越界，直接停
    end
end

if ~isnan(last_valid_lambda)
    disp(['最大合法 lambda = ', num2str(last_valid_lambda)]);
else
    disp('没有找到合法的 lambda');
end
%%  %% 计算牛拉算法对应的极限负载因子——真实λ值
lambda_values = 1:0.001:100;   % lambda 扫描范围
tol   = 1e-6;                 % 收敛容差
maxit = 50;                   % 单个 lambda 的最大迭代次数
max_lambda = NaN;             % 用来保存最后收敛的 λ

for lambda = lambda_values
    % 负荷按 lambda 逐步放大
    pL=[0.8*ones(10,1);1*ones(9,1);1.2*ones(10,1)]*10000*lambda;
    pM=[0.5*ones(7,1);1*ones(6,1);1.5*ones(7,1)]*10000;
    T=Y1^(-1)*diag([-pM;pL])/uref/uref;  
    % 初值
    x = ones(49,1);
    converged = false;

    for k = 1:maxit
        F  = x + T*diag(x)^(-1)*ones(49,1) - ones(49,1);
        J  = eye(49) - T*diag(x)^(-2);
        dx = J \ F;
        x  = x - dx;

        % 判断是否收敛
        if any(isnan(x)) || any(isinf(x))     % 数值溢出
            break
        end
        if norm(dx,inf) < tol                 % 收敛
            converged = true;
            break
        end
    end

    if ~converged
        fprintf('牛顿迭代在 lambda = %.3f 时开始发散。\n', lambda);
        break
    else
        max_lambda = lambda;   % 记录最后一次收敛的 λ
    end
end

fprintf('能够收敛的最大 lambda 为 %.3f\n', max_lambda);
%% ------计算现存判据对应的极限负载因子λ--- %%
lambda_low = 1;        % λ 的下界
lambda_high = 100;     % λ 的上界
tol = 1e-4;            % 精度要求（相当于步长法 0.0001）
max_iter = 100;        % 最多迭代次数
last_valid_lambda = NaN;
last_b1 = NaN;

for iter = 1:max_iter
    lambda_mid = (lambda_low + lambda_high) / 2;
    % 负载和发电功率
   pL=[0.8*ones(10,1);1*ones(9,1);1.2*ones(10,1)]*10000*lambda_mid;
 pM=[0.5*ones(7,1);1*ones(6,1);1.5*ones(7,1)]*10000;
    % 计算 T
    T=Y1^(-1)*diag([-pM;pL])/uref/uref;  
%% 计算第一个判据的数值
b1=4*norm(T,inf);
%计算第二个判据的数值%
b2=norm(T,inf)+3*(norm(T*ones(49,1),inf)/2 )^(2/3);
%计算第三个判据的数值%
b3=2*sqrt(norm(T,inf)*norm(T*ones(49,1),inf))+norm(T*ones(49,1),inf)+norm(T,inf);
    % 判断 b1 是否超过 1
    if b1 <= 1
        last_valid_lambda = lambda_mid;
        last_b1 = b1;
        last_b2 = b2;
        last_b3 = b3;
        lambda_low = lambda_mid;   % b1 太小，可以增大 λ
    else
        lambda_high = lambda_mid;  % b1 太大，缩小 λ
    end

    % 停止条件：区间足够小
    if (lambda_high - lambda_low) < tol
        break;
    end
end

if ~isnan(last_valid_lambda)
    disp(['最大合法 lambda = ', num2str(last_valid_lambda)]);
    disp(['对应的 b1 = ', num2str(last_b1)]);
    disp(['对应的 b2 = ', num2str(last_b2)]);
    disp(['对应的 b3 = ', num2str(last_b3)]);
else
    disp('没有找到合法的 lambda');
end



