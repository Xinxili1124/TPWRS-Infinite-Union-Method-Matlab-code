clear; clc; close all;
%% IEEE-85系统 
Y=zeros(85,85);
Y(1,37)=1; Y(2,43)=0.5; Y(3,81)=0.5; Y(4,83)=4; Y(5,70)=0.25; Y(6,65)=0.5; Y(7,63)=1; Y(8,60)=0.2; Y(9,58)=0.2; Y(10,50)=1; Y(11,44)=5; Y(12,38)=0.25;
Y(12,39)=10; Y(13,45)=2; Y(13,46)=0.2; Y(13,71)=0.1; Y(14,72)=1; Y(15,47)=0.5; Y(15,48)=10; Y(15,68)=0.1; Y(16,49)=10; Y(17,51)=2; Y(17,53)=0.5; Y(18,54)=0.5; Y(18,55)=0.2; Y(18,59)=0.1; Y(19,55)=10; Y(19,56)=0.25; Y(19,64)=0.1; Y(20,77)=0.2; Y(21,38)=0.5; Y(22,40)=0.2; Y(22,41)=1; Y(22,42)=0.5; Y(23,39)=0.2; Y(23,44)=10; Y(24,45)=1; Y(24,50)=0.25; Y(25,72)=0.1; Y(25,73)=1; Y(25,75)=10; Y(26,79)=0.2; Y(26,81)=10; Y(26,82)=4; Y(27,79)=5; Y(28,68)=0.5; Y(28,69)=5; Y(28,70)=10;
Y(29,53)=0.25; Y(30,53)=5; Y(30,54)=10; Y(31,64)=10; Y(31,65)=2; Y(32,56)=5;
Y(33,56)=0.1; Y(33,60)=0.25; Y(33,62)=2; Y(34,62)=4; Y(35,61)=0.5; Y(36,37)=0.2; Y(37,38)=4; Y(39,40)=4; Y(42,43)=10; Y(44,45)=1; Y(46,66)=0.25;
Y(46,47)=4; Y(48,49)=2; Y(48,67)=4; Y(50,51)=1; Y(51,52)=5; Y(57,58)=1; Y(58,59)=2; Y(60,61)=5; Y(62,63)=0.5; Y(71,72)=2; Y(73,74)=2; Y(75,76)=0.5;
Y(76,77)=10; Y(76,81)=0.1; Y(77,78)=5; Y(79,80)=10;  Y(81,84)=4; Y(82,83)=2; Y(83,85)=0.5;
Y=diag((Y+Y')*ones(85,1))-Y-Y';
YSS=Y(1:20,1:20); YSL=Y(1:20, 21:85); YLS=YSL';YLL=Y(21:85,21:85);
K=diag([0.5*ones(10,1); 1*ones(10,1)]);
c=ones(1,20)*K^(-1)*YSS^(-1)*K^(-1)*ones(20,1);alpha=(ones(1,20)*K^(-1)*YSS^(-1)*YSL)';
Y1=YLL-YLS*YSS^(-1)*YSL+alpha*alpha'*c^(-1); %% Y1 is obtained %%
uref=9000;
 pL=[10*ones(17,1);30*ones(16,1);20*ones(17,1)]*1000;
pM=[6*ones(5,1);10*ones(5,1);8*ones(5,1)]*1000;
%% %% ========== 扫描参数 ==========
Ndir  = 360;     % 扫描方向数 
steps = [1e2, 1e2, 1e2, 1e2];   % 每个判据的 λ 步长，自己可调整
%% ========== 四个判据边界 ==========
boundary_tmp = cell(4,1);
h=1;g=34;%% 选中的负载 
m=50;%%负载pL总数
v=65;%%MPPT+CPL总数

for crit = 1:4
    boundary_points = [];
    step = steps(crit);   % 针对当前判据的步长
    for k = 1:Ndir
        theta = 2*pi*(k-1)/Ndir;
        d29 = ones(m,1);
        d29(h)  = cos(theta);
        d29(g) = sin(theta);

        lambda = 0;
        inside = true;

        % 逐步增加功率直到判据不满足
        while inside
            lambda = lambda + step;
            pL_try = pL+ lambda*d29;
            T = Y1^(-1)*diag([-pM; pL_try])/uref/uref;

            switch crit
                case 1
                    bval = 4*norm(T,inf);
                    inside = (bval <= 1);
                case 2
                    bval = norm(T,inf) + 3*(norm(T*ones(v,1),inf)/2)^(2/3);
                    inside = (bval <= 1);
                case 3
                    bval = 2*sqrt(norm(T,inf)*norm(T*ones(v,1),inf)) ...
                         + norm(T*ones(v,1),inf) + norm(T,inf);
                    inside = (bval <= 1);
                case 4
                    T1 = T.*(T>0);
                    T2 = -T.*(T<0);
                    s = T1*ones(v,1);
                    r = T2*ones(v,1);
                    inside = true;
                    for i = 1:length(s)
                        x = s(i); y = r(i);
                        if x <= 2/3
                            if x <= 1/4
                                ok = (y >= 0) && (y <= 0.5*x+1);
                            elseif x <= (3-sqrt(5))/2
                                ok = (y >= 2*sqrt(x)-1) && (y <= 0.5*x+1);
                            else
                                ok = (y >= x^2/(1-x)) && (y <= 0.5*x+1);
                            end
                        else
                            ok = false;
                        end
                        if ~ok
                            inside = false;
                            break;
                        end
                    end
            end
        end

        % 回退一个步长，取边界点
        lambda = lambda - step;
        P1 = pL(h) + lambda*d29(h);
        P2 = pL(g) + lambda*d29(g);
        boundary_points = [boundary_points; [P1, P2]];
    end
    boundary_tmp{crit} = boundary_points;
end
%%  ========== 牛顿真实边界 ==========
boundary_nr = [];
for k = 1:Ndir
    theta = 2*pi*(k-1)/Ndir;
    d29 = ones(m,1);
    d29(h)  = cos(theta);
    d29(g) = sin(theta);

    % --- 二分法搜索 ---
    lambda = 0;
    step =1e5;   % 初始粗步长

    pL_try = pL + lambda*d29;
    T = Y1^(-1)*diag([-pM; pL_try])/uref/uref;
    inside = newton_check(T,v);
    if ~inside
        break;  % 已经越界，跳出
    end
    lambda = lambda + step;

    % refine
    lo = max(0, lambda-step);
    hi = lambda;
    for refine = 1:50
        mid = (lo+hi)/2;
        pL_try = pL + mid*d29;
        T = Y1^(-1)*diag([-pM; pL_try])/uref/uref;
        inside = newton_check(T,v);
        if inside
            lo = mid;
        else
            hi = mid;
        end
    end

    % 边界点
    P1 = pL(h) + lo*d29(h);
    P2 = pL(g) + lo*d29(g);
    boundary_nr = [boundary_nr; [P1, P2]];
end

% ========== 按需求顺序重排 ==========
boundary_all = cell(5,1);
boundary_all{1} = boundary_nr*1e-5;       % Actual (黑色)
boundary_all{2} = boundary_tmp{4}*1e-5;   % Proposed (蓝色)
boundary_all{3} = boundary_tmp{2}*1e-5;   % [29] 玫红
boundary_all{4} = boundary_tmp{3}*1e-5;   % [26] 绿色
boundary_all{5} = boundary_tmp{1}*1e-5;   % [23] 红色
figure; hold on; grid on; box on;

% 颜色顺序: 黑, 蓝, 玫红, 绿, 红
clr   = {'k','b','m','g','r'}; 
% 线型顺序: 实线, 虚线, 点线, 点划线, 点划线 (可调整)
lns   = {'-','--',':','-.','-.'};  
labels = {'Actual bound','Proposed bound','Bound by [29]','Bound by [26]','Bound by [23]'};
lw    = [1.5 1.5 1.5 1.5 1.5];   % 黑色实线稍粗, 其余正常

for crit = 1:5
    plot(boundary_all{crit}(:,1), boundary_all{crit}(:,2), ...
        'Color', clr{crit}, 'LineStyle', lns{crit}, ...
        'LineWidth', lw(crit), 'DisplayName', labels{crit});
end


xlabel('$P_{1}$','Interpreter','latex','FontName','Times New Roman','FontSize',20);
ylabel('$P_{2}$','Interpreter','latex','FontName','Times New Roman','FontSize',20);
lgd = legend('show','Orientation','vertical', ...
    'FontName','Times New Roman','FontSize',12);  % 图例用Times New Roman
lgd.ItemTokenSize = [15,18];   % 调整图例线段长度
set(gca,'FontName','Times New Roman','FontSize',20,'LineWidth',1.1);

% ========== 收敛判定函数 ==========
function converged = newton_check(T,n)
    tol = 1e-10;
    max_iter = 10;
    x = ones(n,1);  % 初始解
    converged = false;

    for it = 1:max_iter
        try
            x_new = x - (eye(n) - T*diag(x.^(-2))) \ ...
                        (x + T*(1./x) - ones(n,1));
        catch
            return; % 矩阵奇异 -> 不收敛
        end
        % --- 收敛误差判定 ---
        error = x_new + T*diag(1./x_new)*ones(n,1) - ones(n,1);
        if max(abs(error)) < tol
            converged = true;
            return;
        end
        x = x_new;
    end
end
